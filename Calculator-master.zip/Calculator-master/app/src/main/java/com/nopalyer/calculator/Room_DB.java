package com.nopalyer.calculator;

import androidx.room.Database;
import androidx.room.RoomDatabase;

// Database annotation takes 2 parameters
// 1- entity and 2- version put version as 1 and entity as the entity specified
// In this case the entity is Stored_Data

@Database(entities = {Stored_Data.class}, version = 1, exportSchema = false)
public abstract class Room_DB extends RoomDatabase {

    public abstract DAO dao();



}

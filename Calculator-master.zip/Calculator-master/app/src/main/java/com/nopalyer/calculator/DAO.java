package com.nopalyer.calculator;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

// so basically annotation means anything starting with @ mark
// This is a Dao means a data access object

@Dao
public interface DAO {

    // The parameter in the below method is actually object of Stored_Data class
    // Basically object of The class in which table name is specified
    // In this case it is Stored_Data as our table name and column is present inside this file

    // The insert annotation specifies that it inserts data into the table

    @Insert
    public void add_Calc(Stored_Data stored_data);

    @Query("select * from Stored_Data")
    public List<Stored_Data> getStored_Data();

}


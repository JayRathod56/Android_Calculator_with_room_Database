package com.nopalyer.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import java.util.List;

public class History_Activity extends AppCompatActivity {

    private TextView TextInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        TextInfo = findViewById(R.id.text_display_info);

        List<Stored_Data> stored_data = MainActivity.room_db.dao().getStored_Data();

        String info = "";

        for (Stored_Data storedData : stored_data){

            String cal = storedData.getCalculation();

            info = info+"\n"+cal;

        }

        TextInfo.setText(info);

    }
}
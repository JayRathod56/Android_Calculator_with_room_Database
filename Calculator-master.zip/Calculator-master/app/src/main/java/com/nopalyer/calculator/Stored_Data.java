package com.nopalyer.calculator;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

// so basically the class will become our table name (in this case its Stored_Data)
// we can also change the table name just by specifing like this
// @Entity(tableName = "_table_name_")

// All the variables inside will become the column name

// In RoomDB we should have at least one primary key

// @ColumnInfo(name = "_column_name_") sets the column name

@Entity
public class Stored_Data {

    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "calculation")
    private String calculation;

    // The above variables are private so to access them we need to set getters and setters methods
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCalculation() {
        return calculation;
    }

    public void setCalculation(String calculation) {
        this.calculation = calculation;
    }
}
